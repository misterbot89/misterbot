/* This software was developed at the National Institute of Standards and
 * Technology by employees of the Federal Government in the course of their
 * official duties. Pursuant to title 17 Section 105 of the United States
 * Code this software is not subject to copyright protection and is in the
 * public domain. NIST assumes no responsibility whatsoever for its use by
 * other parties, and makes no guarantees, expressed or implied, about its
 * quality, reliability, or any other characteristic.

 * We would appreciate acknowledgement if the software is used.
 * The SAMATE project website is: http://samate.nist.gov
*/
#include <mysql.h>
#include <stdio.h>
#include <string.h>

int runSQLCommand(MYSQL *conn, const char *query)
{
	if (mysql_query(conn, query))
	  return 1;
	return 0;
}


int main(int argc, char *argv[]) 
{
   MYSQL *conn;
   MYSQL_RES *res;
   MYSQL_ROW row;

   char *server = "localhost";
   char *user = "root";
   char *password = "myovertropfortpassword";
   char *database = "bank";
   
	if (argc < 2)
	{
		printf("You should give an entry parameter!\n");
		return 0;		
	}
	
   conn = mysql_init(NULL);
   
   /* Connect to database */
   if (!mysql_real_connect(conn, server,
         user, password, database, 0, NULL, 0)) {
      fprintf(stderr, "%s\n", mysql_error(conn));
      return 0;
   }

   /* send SQL query */
   char query[512];
   char *fmtString = "SELECT * FROM users WHERE firstname LIKE '%s'";
   
   /* No more buffer overflow */
	if ((strlen(argv[1]) + strlen(fmtString)) > 512){
		printf("The entry is too long...\n");
		return 0;		
	}
	
	char param_escaped[512];
	// sanitize the query string
	mysql_real_escape_string(conn, param_escaped, argv[1], strlen(argv[1]));
	sprintf(query,fmtString,param_escaped);
	if (runSQLCommand(conn, (const char *)query))
	{
	  fprintf(stderr, "%s\n", mysql_error(conn));
	  return 0;
	}
	
	res = mysql_use_result(conn);
	
	/* output fields 1 and 2 of each row */
	while ((row = mysql_fetch_row(res)) != NULL)
	  printf("%s %s\n", row[1], row[2]);
	
	/* Release memory used to store results and close connection */
	mysql_free_result(res);
	mysql_close(conn);
	return 0;
}
